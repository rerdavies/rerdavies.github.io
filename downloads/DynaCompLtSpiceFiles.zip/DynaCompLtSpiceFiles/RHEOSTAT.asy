Version 4
SymbolType BLOCK
LINE Normal -18 -11 -26 0
LINE Normal -8 8 -18 -11
LINE Normal 3 -11 -8 8
LINE Normal 12 8 3 -11
LINE Normal 16 0 12 8
LINE Normal 32 0 16 0
LINE Normal 2 16 7 16
LINE Normal 9 12 7 16
LINE Normal 2 16 9 12
LINE Normal 6 14 -8 -16
LINE Normal -26 0 -48 0
TEXT -45 -11 Right 0 1
TEXT 29 -12 Left 0 2
WINDOW 0 -1 -45 Center 2
WINDOW 39 3 28 Center 2
SYMATTR SpiceLine <SpiceLine>
SYMATTR Prefix X
SYMATTR SpiceModel RHEOSTAT
SYMATTR Value2 RMIN=1 RMAX=10k WIPER=0.5
SYMATTR Description 2-Terminal Variable Resistor (Rheostat)
SYMATTR ModelFile pot_subckt.lib
PIN -48 0 NONE 8
PINATTR PinName 1
PINATTR SpiceOrder 1
PIN 32 0 NONE 8
PINATTR PinName 2
PINATTR SpiceOrder 2
