Version 4
SymbolType CELL
LINE Normal -32 32 12 56
LINE Normal -32 96 12 72
LINE Normal -32 32 -32 96
LINE Normal -27 48 -19 48
LINE Normal -26 80 -18 80
LINE Normal -23 52 -23 44
LINE Normal 32 88 32 96
LINE Normal 32 88 28 84
LINE Normal 28 72 28 84
LINE Normal -10 57 -2 57
LINE Normal -6 61 -6 53
LINE Normal 0 50 0 32
LINE Normal 0 78 0 96
CIRCLE Normal 32 76 8 52
CIRCLE Normal 48 76 24 52
TEXT 18 34 Left 2 LM13700
WINDOW 0 20 8 Left 2
SYMATTR Prefix X
SYMATTR SpiceModel LM13700/NS
SYMATTR Description Behavioral Operational Transconductance Amplifier with multiplying input
SYMATTR ModelFile LM13700.mod
PIN 32 96 NONE 0
PINATTR PinName 1
PINATTR SpiceOrder 1
PIN -32 64 NONE 8
PINATTR PinName 2
PINATTR SpiceOrder 2
PIN -32 48 NONE 0
PINATTR PinName 3
PINATTR SpiceOrder 3
PIN -32 80 NONE 0
PINATTR PinName 4
PINATTR SpiceOrder 4
PIN 48 64 NONE 0
PINATTR PinName out
PINATTR SpiceOrder 5
PIN 0 96 NONE 8
PINATTR PinName 6
PINATTR SpiceOrder 6
PIN -32 112 NONE 8
PINATTR PinName bi
PINATTR SpiceOrder 7
PIN -16 112 NONE 8
PINATTR PinName bo
PINATTR SpiceOrder 8
PIN 0 32 NONE 8
PINATTR PinName 11
PINATTR SpiceOrder 9
