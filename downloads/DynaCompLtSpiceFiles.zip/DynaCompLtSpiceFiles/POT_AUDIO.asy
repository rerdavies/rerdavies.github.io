* ============================================================================
* POT_AUDIO.asy - Audio Taper (Logarithmic) Potentiometer Symbol
* ============================================================================
* Save this section as a separate file named POT_AUDIO.asy
Version 4
SymbolType BLOCK
LINE Normal -32 -48 -32 48
LINE Normal 32 -48 -32 -48
LINE Normal 32 48 32 -48
LINE Normal -32 48 32 48
LINE Normal 0 -80 0 -48
LINE Normal 0 80 0 48
LINE Normal -64 0 -32 0
CIRCLE Normal -8 8 8 -8
CIRCLE Normal -4 4 4 -4
LINE Normal -8 0 -32 0
LINE Normal 8 0 32 0
LINE Normal 0 -8 -16 -24
LINE Normal -12 -28 -16 -24
LINE Normal -16 -20 -16 -24
ARC Normal -24 -32 8 0 -8 -16 -24 -16
TEXT -28 -48 Left 0 1
TEXT -28 48 Left 0 3
TEXT -64 0 Left 0 2
TEXT 48 -64 Left 2 POT_A
WINDOW 0 48 -48 Left 2
WINDOW 3 48 -32 Left 2
WINDOW 39 48 -16 Left 2
WINDOW 40 48 0 Left 2
SYMATTR Value POT_AUDIO
SYMATTR Prefix X
SYMATTR SpiceModel POT_AUDIO
SYMATTR Value2 RTOTAL=100k WIPER=0.5
SYMATTR Description Audio Taper (Logarithmic) Potentiometer
SYMATTR ModelFile pot_subckt.lib
PIN 0 -80 NONE 8
PINATTR PinName 1
PINATTR SpiceOrder 1
PIN -64 0 NONE 8
PINATTR PinName 2
PINATTR SpiceOrder 2
PIN 0 80 NONE 8
PINATTR PinName 3
PINATTR SpiceOrder 3
