Version 4
SymbolType BLOCK
LINE Normal 0 -48 0 -32
LINE Normal -16 -24 0 -32
LINE Normal 16 -16 -16 -24
LINE Normal -16 -8 16 -16
LINE Normal 16 0 -16 -8
LINE Normal -16 8 16 0
LINE Normal 16 16 -16 8
LINE Normal -16 24 16 16
LINE Normal 0 32 -16 24
LINE Normal 0 48 0 32
LINE Normal -48 0 -16 0
LINE Normal -16 0 -24 -8
LINE Normal -24 8 -24 -8
LINE Normal -24 8 -16 0
TEXT 4 -48 Left 0 1
TEXT 4 48 Left 0 3
TEXT -48 -4 Right 0 2
WINDOW 0 23 -40 Left 2
SYMATTR Prefix X
SYMATTR SpiceModel POT_LINEAR
SYMATTR SpiceLine WIPER=0.5 
SYMATTR SpiceLine2 R=10k
WINDOW 40 22 -10 Left 2
SYMATTR Description Potentiometer with parameter-controlled wiper position and linear taper.
SYMATTR ModelFile pot.lib
PIN 0 -48 NONE 8
PINATTR PinName 1
PINATTR SpiceOrder 1
PIN -48 0 NONE 8
PINATTR PinName 2
PINATTR SpiceOrder 2
PIN 0 48 NONE 8
PINATTR PinName 3
PINATTR SpiceOrder 3
